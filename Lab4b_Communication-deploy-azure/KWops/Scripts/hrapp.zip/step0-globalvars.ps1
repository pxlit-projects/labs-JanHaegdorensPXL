# choose a name containing your initials, like rg-fullstack-kh
$global:RESOURCE_GROUP="jh-fullstack"

# choose a region nearby, this value is probably ok
$global:LOCATION="westeurope"

# contains the sln-file, change to your own path
$global:SLNDIR="C:\Users\janha\Desktop\School\Jaar 4\Fullstack-Net\labs-JanHaegdorensPXL\Lab3b_DevOps-module-deploy-azure\KWops\src"