# This deletes every resource and the resource group itself
# Your whole application will be vanished
az group delete `
  --name $RESOURCE_GROUP