az group create `
  --resource-group $RESOURCE_GROUP `
  --location "$LOCATION"